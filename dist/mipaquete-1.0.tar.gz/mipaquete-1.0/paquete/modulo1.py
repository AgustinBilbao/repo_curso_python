def funcionpaquete():
    print("hola estoy en mi paquete")